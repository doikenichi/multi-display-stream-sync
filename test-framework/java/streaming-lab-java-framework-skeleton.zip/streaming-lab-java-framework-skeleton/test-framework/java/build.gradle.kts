import org.gradle.api.tasks.testing.Test

plugins {
    id("java")
}

group = "com.streaminglab.testframework"
version = "1.0-SNAPSHOT"

java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(25)
    }
}

repositories {
    mavenCentral()
}

dependencies {
    // JUnit using BOM
    testImplementation(platform("org.junit:junit-bom:6.1.1"))
    testImplementation("org.junit.jupiter:junit-jupiter")

    // Cucumber using BOM
    testImplementation(platform("io.cucumber:cucumber-bom:7.34.4"))
    testImplementation("io.cucumber:cucumber-java")
    testImplementation("io.cucumber:cucumber-junit-platform-engine")
    testImplementation("io.cucumber:cucumber-picocontainer")
    testImplementation("org.junit.platform:junit-platform-suite")

    // AssertJ using BOM
    testImplementation(platform("org.assertj:assertj-bom:3.27.7"))
    testImplementation("org.assertj:assertj-core")

    // Allows Gradle to launch JUnit Platform tests reliably.
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}

// Sets the location of shared Cucumber feature files.
tasks.processTestResources {
    from("../features") {
        into("features")
    }
}

tasks.withType<Test> {
    useJUnitPlatform {
        // When running an individual Cucumber feature/scenario, run only the Cucumber engine.
        System.getProperty("cucumber.features")?.let { includeEngines("cucumber") }
    }

    // Pass selected system properties to Cucumber.
    System.getProperty("cucumber.features")?.let { systemProperty("cucumber.features", it) }
    System.getProperty("cucumber.filter.tags")?.let { systemProperty("cucumber.filter.tags", it) }
    System.getProperty("cucumber.filter.name")?.let { systemProperty("cucumber.filter.name", it) }
    System.getProperty("cucumber.plugin")?.let { systemProperty("cucumber.plugin", it) }

    // Workaround: Gradle does not include enough information to disambiguate
    // between different Cucumber examples and scenarios.
    systemProperty("cucumber.junit-platform.naming-strategy", "long")

    // Allows runs using -Dtest.framework.profile=local|ci|docker|k8s.
    systemProperty(
        "test.framework.profile",
        System.getProperty("test.framework.profile", "local")
    )

    // Shows passed/skipped/failed test events in the console.
    testLogging {
        events("passed", "skipped", "failed")
    }
}
