package com.streaminglab.testframework.context;

import com.streaminglab.testframework.model.ArtifactPaths;
import com.streaminglab.testframework.model.PlaybackObservation;
import java.time.Instant;
import java.util.UUID;

/**
 * Scenario-scoped mutable state shared across Cucumber step definition classes.
 *
 * <p>This is intentionally a class, not a record, because values are discovered progressively while
 * the scenario executes.
 */
public class ScenarioContext {

  private UUID testRunId;
  private String currentTestRunStatus;
  private String streamId;
  private String hlsStreamUrl;
  private String displayClientUrl;
  private ArtifactPaths artifactPaths;
  private Instant startedAt;
  private PlaybackObservation playbackObservation;

  public UUID getTestRunId() {
    return testRunId;
  }

  public void setTestRunId(UUID testRunId) {
    this.testRunId = testRunId;
  }

  public String getCurrentTestRunStatus() {
    return currentTestRunStatus;
  }

  public void setCurrentTestRunStatus(String currentTestRunStatus) {
    this.currentTestRunStatus = currentTestRunStatus;
  }

  public String getStreamId() {
    return streamId;
  }

  public void setStreamId(String streamId) {
    this.streamId = streamId;
  }

  public String getHlsStreamUrl() {
    return hlsStreamUrl;
  }

  public void setHlsStreamUrl(String hlsStreamUrl) {
    this.hlsStreamUrl = hlsStreamUrl;
  }

  public String getDisplayClientUrl() {
    return displayClientUrl;
  }

  public void setDisplayClientUrl(String displayClientUrl) {
    this.displayClientUrl = displayClientUrl;
  }

  public ArtifactPaths getArtifactPaths() {
    return artifactPaths;
  }

  public void setArtifactPaths(ArtifactPaths artifactPaths) {
    this.artifactPaths = artifactPaths;
  }

  public Instant getStartedAt() {
    return startedAt;
  }

  public void setStartedAt(Instant startedAt) {
    this.startedAt = startedAt;
  }

  public PlaybackObservation getPlaybackObservation() {
    return playbackObservation;
  }

  public void setPlaybackObservation(PlaybackObservation playbackObservation) {
    this.playbackObservation = playbackObservation;
  }
}
