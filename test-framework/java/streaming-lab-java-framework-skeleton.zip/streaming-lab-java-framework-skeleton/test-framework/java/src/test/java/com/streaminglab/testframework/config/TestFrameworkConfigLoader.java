package com.streaminglab.testframework.config;

/** Loads the active test-framework profile from shared YAML config. */
public class TestFrameworkConfigLoader {

  public TestFrameworkConfig load() {
    return load(System.getProperty("test.framework.profile", "local"));
  }

  public TestFrameworkConfig load(String profile) {
    throw new UnsupportedOperationException(
        "Config loading is not implemented yet. Next step: load ../contract/examples/test-framework-"
            + profile
            + ".yaml and map it to TestFrameworkConfig.");
  }
}
