# Streaming Lab Test Framework

This folder contains the shared BDD test cases, technical contracts, contract validation tools, and future polyglot test-framework implementations for Streaming Lab.

The first milestone is intentionally small:

```text
Create a test run through streaming-lab-orchestration-api
Prepare the test run
Start the stream
Open the Display Client
Verify HLS playback progresses
Write schema-compliant evidence
Stop the test run
Validate artifacts
```

## Structure

```text
test-framework/
  features/                 Shared executable BDD test cases
  contract/                 Schemas, examples, docs, and conformance rules
  tools/                    Shared contract validation tools
  jvm/                      Future Java + JUnit Platform + Cucumber JVM implementation
  node/                     Future Node.js + TypeScript + CucumberJS implementation
  python/                   Future Python + pytest + pytest-bdd implementation
```

## Core rules

- `features/` is the shared BDD test-case repository.
- `contract/` defines the rules every implementation must satisfy.
- `streaming-lab-orchestration-api` owns `testRunId` and test-run lifecycle state.
- Java, Node/TypeScript, and Python implementations must not fork feature files.
- All generated evidence must use the `testRunId` returned by the orchestrator.
- Runtime artifacts should not be committed to the repository.

## Validate contracts

From `test-framework/tools/evidence-contract-validator`:

```bash
npm install
npm run typecheck
npm run validate:contracts
```
